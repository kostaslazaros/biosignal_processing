% Lab03 
% Exercise 2
% Lazaros Konstantinos-Panagiotis
% 01639

function [x] = unitStep (t, t0)
  x = (t>=t0);
endfunction
