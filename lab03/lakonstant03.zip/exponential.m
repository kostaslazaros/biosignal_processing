% Lab03 
% Exercise 1 part b
% Lazaros Konstantinos-Panagiotis
% 01639

function [x] = exponential (a, t, t0)
  x = a .^ (t - t0);
endfunction
