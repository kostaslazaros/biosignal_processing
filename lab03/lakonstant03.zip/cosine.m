% Lab03 
% Exercise 2 cosine function
% Lazaros Konstantinos-Panagiotis
% 01639


function [x] = cosine (t, A, f, phi)
  x = A * cos(2*pi*f .*t + phi);

endfunction
