% lab exercrise set 04
% complex exponent
% Lazaros Konstantinos-Panagiotis
% 01639

function [x] = complex_exponent (A, f, t, phi)
  x = A * exp(j *(2*pi*f*t + phi)); 
endfunction
