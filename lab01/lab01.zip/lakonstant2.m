% Lab 01
% Exercise 2
% By Lazaros Konstantinos-Panagiotis
% Serial number: 01639

for i =[1:10]
  fprintf('test %d', i)
  disp(' ')
endfor
