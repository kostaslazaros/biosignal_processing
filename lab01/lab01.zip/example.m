% Lab 01
% Exercise 4
% Usage examples for function mymin
% By Lazaros Konstantinos-Panagiotis
% Serial number: 01639

A = [54 23 15 32 100];

B = [54;23;15;32;100];

C = [43 32 54; 21 32 43; 43 12 53];

mymin(A)

mymin(B)

mymin(C)