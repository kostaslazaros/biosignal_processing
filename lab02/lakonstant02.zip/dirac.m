% Lazaros Konstantinos-Panagiotis 
% 01639

function [x] = dirac (t, t0)
  x = (t == t0);
endfunction
