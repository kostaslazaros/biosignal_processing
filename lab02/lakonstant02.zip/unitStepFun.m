% Lazaros Konstantinos-Panagiotis 
% 01639

function [x] = unitStepFun (t, t0)
  x = (t>=t0);

endfunction
